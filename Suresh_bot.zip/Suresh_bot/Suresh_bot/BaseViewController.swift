//
//  BaseViewController.swift
//  Suresh_bot
//
//  Created by Suresh T on 08/09/20.
//  Copyright © 2020 Suresh T. All rights reserved.
//

import UIKit
import Kommunicate

class BaseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    private func setupApplicationKey(_ applicationId: String) {
           guard !applicationId.isEmpty else {
               fatalError("Please pass your AppId in the AppDelegate file.")
           }
           Kommunicate.setup(applicationId: applicationId)
       }
    
    private func userWithUserId(
           _ userId: String,
           andApplicationId applicationId: String) -> KMUser {
           let kmUser = KMUser()
           kmUser.userId = userId
           kmUser.applicationId = applicationId
           return kmUser
       }
    
    private func registerUser(_ kmUser: KMUser) {
          
           Kommunicate.registerUser(kmUser, completion: {
               response, error in
               
               guard error == nil else {
                   print("[REGISTRATION] Kommunicate user registration error: %@", error.debugDescription)
                   return
               }
               print("User registration was successful: %@ \(String(describing: response?.isRegisteredSuccessfully()))")
               if let viewController = UIStoryboard(name: "Main", bundle: nil)
                   .instantiateViewController(withIdentifier: "NavViewController") as? UINavigationController {
                   viewController.modalPresentationStyle = .fullScreen
                   self.present(viewController, animated:true, completion: nil)
               }
           })
       }
    
    @IBAction func loginAsVisitor(_ sender: Any) {
        
        let applicationId = (UIApplication.shared.delegate as! AppDelegate).appId
        setupApplicationKey(applicationId)

        let kmUser = userWithUserId(Kommunicate.randomId(), andApplicationId: applicationId)
        registerUser(kmUser)
    }

}
