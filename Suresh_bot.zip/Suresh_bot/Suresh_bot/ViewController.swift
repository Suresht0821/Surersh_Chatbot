//
//  ViewController.swift
//  Suresh_bot
//
//  Created by Suresh T on 08/09/20.
//  Copyright © 2020 Suresh T. All rights reserved.
//

import UIKit
import Kommunicate

class ViewController: UIViewController {


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
        
    @IBAction func launchConversation(_ sender: Any) {
           view.isUserInteractionEnabled = false

           Kommunicate.createAndShowConversation(from: self, completion: {
               error in
               self.view.isUserInteractionEnabled = true
               if error != nil {
                   print("Error while launching")
               }
           })
       }


}

